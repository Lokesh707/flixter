package com.example.flixsterpart2

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

private const val TV_TAG = "TVDetail"

class Tv_Activity : AppCompatActivity() {
    private lateinit var postImageView: ImageView
    private lateinit var titleTextView: TextView
    private lateinit var ratingTextView: TextView
    private lateinit var rateNumTextView: TextView
    private lateinit var releaseDateTextView: TextView
    private lateinit var breifTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.movie_des)

        postImageView = findViewById(R.id.post)
        titleTextView = findViewById(R.id.title)
        ratingTextView = findViewById(R.id.rating)
        rateNumTextView = findViewById(R.id.rateNUm)
        releaseDateTextView = findViewById(R.id.ReleaseDate)
        breifTextView = findViewById(R.id.brief)

        val tv = intent.getSerializableExtra(TV_EXTRA) as Tv

        Glide.with(this)
            .load("https://image.tmdb.org/t/p/w500" + tv.poster_path)
            .into(postImageView)

        titleTextView.text = tv.title.toString()
        ratingTextView.text = "Rate : " + tv.vote.toString()
        rateNumTextView.text = "Rate Count: " + tv.count.toString()
        releaseDateTextView.text = "Release Date: " + tv.release_date
        breifTextView.text = "Overview: " + tv.overview

    }
}