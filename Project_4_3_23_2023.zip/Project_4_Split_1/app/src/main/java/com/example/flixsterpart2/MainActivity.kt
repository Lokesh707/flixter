package com.example.flixsterpart2

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL
import androidx.recyclerview.widget.RecyclerView
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import com.example.flixsterpart2.databinding.ActivityMainBinding
import kotlinx.serialization.json.Json
import okhttp3.Headers
import org.json.JSONException

fun createJson() = Json {
    isLenient = true
    ignoreUnknownKeys = true
    useAlternativeNames = false
}

fun tvCreateJson() = Json {
    isLenient = true
    ignoreUnknownKeys = true
    useAlternativeNames = false

}
private const val TAG = "MainActivity"
private const val MOVIE_SEARCH_URL = "https://api.themoviedb.org/3/movie/popular?api_key=a07e22bc18f5cb106bfe4cc1f83ad8ed"
private const val TV_SEARCH_URL = "https://api.themoviedb.org/3/tv/top_rated?api_key=a07e22bc18f5cb106bfe4cc1f83ad8ed"
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var moviesRecyclerView: RecyclerView
    private lateinit var tvsRecyclerView: RecyclerView
    private lateinit var movieAdapter: MovieAdapter
    private lateinit var tvAdapter: TvAdapter
    private val movies = mutableListOf<Movie>()
    private val tvs = mutableListOf<Tv>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set up view binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up movie RecyclerView
        movieAdapter = MovieAdapter(this, movies)
        moviesRecyclerView = binding.rot
        moviesRecyclerView.adapter = movieAdapter
        moviesRecyclerView.layoutManager = LinearLayoutManager(this, HORIZONTAL, false)

        // Set up TV RecyclerView
        tvAdapter = TvAdapter(this, tvs)
        tvsRecyclerView = binding.rot1
        tvsRecyclerView.adapter = tvAdapter
        tvsRecyclerView.layoutManager = LinearLayoutManager(this, HORIZONTAL, false)

        // Fetch movie data
        val movieClient = AsyncHttpClient()
        movieClient.get(MOVIE_SEARCH_URL, object : JsonHttpResponseHandler() {
            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                response: String?,
                throwable: Throwable?
            ) {
                Log.e(TAG, "Failed to fetch movies: $statusCode")
            }

            override fun onSuccess(statusCode: Int, headers: Headers, json: JSON) {
                Log.i(TAG, "Successfully fetched movies: $json")
                try {
                    val parsedJson: BaseResponse = createJson().decodeFromString(
                        BaseResponse.serializer(),
                        json.jsonObject.toString()
                    )
                    parsedJson.result?.let { list: List<Movie> ->
                        movies.addAll(list)
                        movieAdapter.notifyDataSetChanged()
                    }
                } catch (e: JSONException) {
                    Log.e(TAG, "Exception: $e")
                }
            }
        })

        // Fetch TV data
        val tvClient = AsyncHttpClient()
        tvClient.get(TV_SEARCH_URL, object : JsonHttpResponseHandler() {
            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                response: String?,
                throwable: Throwable?
            ) {
                Log.e(TAG, "Failed to fetch TV shows: $statusCode")
            }

            override fun onSuccess(statusCode: Int, headers: Headers, json: JSON) {
                Log.i(TAG, "Successfully fetched TV shows: $json")
                try {
                    val parsedJson: TvBaseResponse = tvCreateJson().decodeFromString(
                        TvBaseResponse.serializer(),
                        json.jsonObject.toString()
                    )
                    parsedJson.result?.let { list: List<Tv> ->
                        tvs.addAll(list)
                        tvAdapter.notifyDataSetChanged()
                    }
                } catch (e: JSONException) {
                    Log.e(TAG, "Exception: $e")
                }
            }
        })
    }

}
