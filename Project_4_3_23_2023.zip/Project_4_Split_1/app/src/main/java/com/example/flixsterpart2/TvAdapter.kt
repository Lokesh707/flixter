package com.example.flixsterpart2

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.flixsterpart2.databinding.TvBinding


const val TV_EXTRA = "TV_EXTRA"
private const val TAG = "TVAdapter"

class TvAdapter(private val context: Context, private val tvList: List<Tv>) :
    RecyclerView.Adapter<TvAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = TvBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tv = tvList[position]
        holder.bind(tv)
    }

    override fun getItemCount(): Int = tvList.size

    inner class ViewHolder(private val binding: TvBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val tvm = tvList[absoluteAdapterPosition]
                val intent = Intent(context, Tv_Activity::class.java).apply {
                    putExtra(TV_EXTRA, tvm)
                }
                context.startActivity(intent)
            }
        }

        fun bind(movie: Tv) {
            with(binding) {
                title.text = movie.title
                rating.text = "Rate: ${movie.vote}"

                Glide.with(context)
                    .load("https://image.tmdb.org/t/p/w500${movie.poster_path}")
                    .into(post)
            }
        }
    }
}