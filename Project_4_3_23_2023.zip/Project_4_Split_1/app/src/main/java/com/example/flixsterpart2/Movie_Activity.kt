package com.example.flixsterpart2

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.flixsterpart2.R


private const val MOVIE_TAG = "MovieDetail"

class Movie_Activity : AppCompatActivity() {
    private lateinit var postImageView: ImageView
    private lateinit var titleTextView: TextView
    private lateinit var ratingTextView: TextView
    private lateinit var rateNumTextView: TextView
    private lateinit var releaseDateTextView: TextView
    private lateinit var breifTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.movie_des)

        postImageView = findViewById(R.id.post)
        titleTextView = findViewById(R.id.title)
        ratingTextView = findViewById(R.id.rating)
        rateNumTextView = findViewById(R.id.rateNUm)
        releaseDateTextView = findViewById(R.id.ReleaseDate)
        breifTextView = findViewById(R.id.brief)

        val movie = intent.getSerializableExtra(MOVIE_EXTRA) as Movie

        Glide.with(this)
            .load("https://image.tmdb.org/t/p/w500" + movie.poster_path)
            .into(postImageView)

        titleTextView.text = movie.title.toString()
        ratingTextView.text = "Rate : " + movie.vote.toString()
        rateNumTextView.text = "Rate Count: " + movie.count.toString()
        releaseDateTextView.text = "Release Date: " + movie.release_date
        breifTextView.text = "Overview: " + movie.overview

    }
}